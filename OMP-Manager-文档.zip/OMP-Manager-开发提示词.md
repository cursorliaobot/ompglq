# OMP Manager 开发提示词

> 用法：把本文件与《OMP Manager 完整需求文档》一起放在项目根目录，然后把下面的任务交给编码 Agent。需求文档是产品事实来源；本提示词规定实现方法、顺序和质量门槛。

## 你的角色

你是一名资深桌面应用架构师、Rust/TypeScript 工程师和应用安全工程师。请从零实现一个可运行、可测试、可打包的 **OMP Manager**，用于图形化管理 [Oh My Pi（OMP）](https://github.com/can1357/oh-my-pi) 的项目目录、Profile、历史会话、账号凭证、模型角色和启动终端。

这不是静态原型，也不是只画界面。最终结果必须能在 Windows 与 Linux 上实际探测并启动本机 OMP。不要重写 OMP 的 Agent 功能；应用是 OMP 的安全编排与管理层。

如果项目根目录存在 `OMP-Manager-完整需求文档.md`，请先完整阅读并将其视为权威需求。本提示词与其冲突时，优先遵守需求文档。

## 工作方式

1. 先检查现有仓库、`AGENTS.md`、构建工具和未提交改动；保护用户已有工作。
2. 先做兼容性验证和架构骨架，再实现纵向可运行流程，不要先堆出一套无法连接 OMP 的页面。
3. 每个里程碑都必须包含真实实现、测试、错误处理和文档；禁止用假数据冒充已完成集成。
4. 遇到 OMP 版本差异时使用能力探测和适配器，不靠散落的版本判断。
5. 只有会改变产品方向、造成不可逆影响或确实阻塞实现的事项才询问用户；普通技术选择按本文推荐方案直接推进，并记录理由。
6. 不要声称“全部凭证管理”已经完成，除非目标 OMP 版本上的列出、添加/登录、禁用、注销/删除和测试均有可验证行为。缺少安全接口时应明确降级，而不是直接操作内部数据库。
7. 每完成一个里程碑，报告：完成项、改动文件、运行方法、测试结果、仍受 OMP 能力限制的部分。

## 产品结论（不要再次询问）

- 桌面平台：Windows 与 Linux。
- 第一版本机运行；架构预留 WSL/SSH，但本轮不实现远程连接。
- 项目以本地目录为核心。进入项目后先列出该路径下全部 OMP 历史会话，由用户选择。
- 恢复会话时显示原模型与账号设置，可原样继续，也可修改后启动。
- 新会话保存项目固定默认值，启动前可临时修改。
- 同时支持内嵌 PTY 终端和外部系统终端。
- 完整管理 OMP 本地账号与凭证，并提供默认不计费的可用性测试。
- 支持常见外部本地管理器/文件的一键导入，以及用户主动触发的单向重新同步。
- 模型角色默认只展示常用角色，高级设置展示 OMP 当前版本的全部角色。
- 账号选择默认交给 OMP 自动调度；可按项目固定 Profile，有稳定接口时才允许固定具体凭证。
- OMP 缺失或过旧时支持一键安装、升级和重新检测。
- 先自用，但代码、权限、迁移和打包按未来公开发布设计。
- UI 默认简体中文，从第一天使用 i18n key，并预留英文。

## 实现前必须核对的官方资料

不要凭记忆实现 OMP 集成。开始编码前读取当时最新的官方文档和目标版本源代码，至少核对：

- [OMP 仓库与安装说明](https://github.com/can1357/oh-my-pi)
- [CLI Reference](https://github.com/can1357/oh-my-pi/blob/main/docs/cli-reference.md)
- [Settings](https://github.com/can1357/oh-my-pi/blob/main/docs/settings.md)
- [Models](https://github.com/can1357/oh-my-pi/blob/main/docs/models.md)
- [Session Format](https://github.com/can1357/oh-my-pi/blob/main/docs/session.md)
- [Auth Broker and Gateway](https://github.com/can1357/oh-my-pi/blob/main/docs/auth-broker-gateway.md)
- [Secrets](https://github.com/can1357/oh-my-pi/blob/main/docs/secrets.md)
- [文件夹自动选择 Profile 的公开议题](https://github.com/can1357/oh-my-pi/issues/9655)
- [Tauri Shell Plugin](https://v2.tauri.app/plugin/shell/)
- [Tauri Capabilities](https://v2.tauri.app/security/capabilities/)
- [portable-pty](https://docs.rs/portable-pty/latest/portable_pty/)

建立 `docs/omp-compatibility.md`，记录：

- 实际验证的 OMP 版本与可执行路径。
- 每个命令、参数、JSON 字段和退出码的验证结果。
- 哪些能力来自 CLI，哪些来自 Auth Broker/Gateway，哪些只能调用 OMP 自身交互流程。
- 最低支持版本和降级行为。
- 使用的脱敏 fixture 来源；不得提交真实账号、Token、项目会话或用户路径。

## 推荐技术栈

除非现有仓库已确定了等价技术栈，否则使用：

- Tauri 2.x 桌面壳。
- React + TypeScript + Vite 前端，启用严格 TypeScript。
- Rust 后端，负责进程、PTY、文件、SQLite、脱敏和安全边界。
- xterm.js 渲染内嵌终端。
- Rust `portable-pty` 提供 Windows ConPTY 与 Linux PTY。
- SQLite 保存项目绑定、会话索引、别名、导入记录、回收站和设置。
- i18n 框架，默认 `zh-CN`，提供最小 `en` 资源占位但不硬编码中文到组件逻辑。
- 使用当前稳定版本并锁定依赖；不要未经评估混用多个状态管理、UI 或数据库框架。

若采用组件库，应满足键盘可用、深浅主题、对话框焦点锁定和中文排版；不要为了视觉效果引入需要远端运行的组件。

## 目标目录结构

可以根据仓库调整命名，但必须保持职责清晰：

```text
apps/desktop/
  src/
    app/                 # 路由、布局、i18n、主题
    features/
      dashboard/
      projects/
      sessions/
      credentials/
      models/
      imports/
      terminals/
      diagnostics/
      trash/
    components/
    bindings/            # 生成/封装的 Tauri 调用类型
  src-tauri/
    src/
      commands/          # 最小白名单 IPC
      domain/            # 领域类型和规则
      services/
      adapters/
        omp/
        importers/
        targets/
      infrastructure/
        db/
        fs/
        process/
        pty/
        secrets/
        logging/
    capabilities/
tests/
  fixtures/omp/          # 合成、脱敏、多版本 fixture
docs/
  architecture.md
  threat-model.md
  omp-compatibility.md
  development.md
```

如果使用 workspace/monorepo，保证根目录有一条命令可运行开发环境、测试和打包。

## 第一原则：不要绕过 OMP

按以下优先级集成：

1. OMP 官方 CLI 的结构化 JSON 输出。
2. OMP Auth Broker/Gateway 的公开接口。
3. OMP 自身交互流程（例如 OAuth/登录），在内嵌或外部终端中安全承载。
4. 只有在 M0 证明公开接口确实不足时，才实现一个最小、版本化的 companion bridge；它必须调用 OMP 的公开包/导出接口，有契约测试和严格版本门控。

严禁：

- 直接写 `agent.db`。
- 根据未声明的 SQLite 表结构实现凭证 CRUD。
- 手工改写会话 JSONL 来恢复、分叉或切换模型。
- 从 WebView 暴露任意 shell 执行。
- 为了“看起来完成”而静默选择别的账号或模型。

可以只读解析会话 JSONL 以建立列表和预览，但解析器必须容忍未知字段、截断文件和正在追加的文件，且永不写回。

## 架构契约

### 1. ExecutionTarget

业务层不能直接依赖本机文件系统和进程 API。定义异步 `ExecutionTarget` 抽象，至少覆盖：

- `probe()`
- `canonicalize_path(path)`
- `resolve_git_identity(path)`
- `run_omp(request)`
- `spawn_pty(launch_plan)`
- `open_external_terminal(launch_plan)`
- `read_allowed_file(request)`
- `atomic_write_allowed_file(request)`
- `health_check()`

第一版只实现 `LocalTarget`，但所有项目、Profile、会话和安装记录都包含 `target_id`。不要在 UI 中放置不能工作的 WSL/SSH 开关。用文档和接口测试证明以后可以加入 `WslTarget`、`SshTarget`。

### 2. OmpAdapter

定义单一 OMP 适配层，至少提供：

- 安装发现、版本与能力探测。
- Profile/Agent 目录发现。
- 有效配置和配置架构读取。
- 模型列表与角色列表。
- 项目会话扫描、会话预览和状态解析。
- 凭证引用列表、健康检查与受支持的管理操作。
- 新建/恢复/分叉/导出 LaunchPlan。
- 安装、升级、重新检测。

所有结果使用领域 DTO，不把原始 CLI 文本直接传给前端。错误对象包含：稳定错误码、用户可读的中文消息、可执行建议、已脱敏技术信息和是否可重试。

### 3. CredentialBackend

至少支持以下实现/模式：

- `BrokerCredentialBackend`：通过官方 Auth Broker/Gateway 列出、导入、刷新、禁用、删除和检查。
- `NativeInteractiveCredentialBackend`：当本机 Profile 没有安全 CRUD API 时，启动 OMP 自身认证流程，完成后刷新清单。
- 可选 `VersionedCompanionBackend`：仅在 M0 确认需要且有公开包接口时加入。

每个后端返回能力标志，例如 `can_list`、`can_login`、`can_disable`、`can_delete`、`can_pin`、`can_safe_check`、`can_strict_check`。UI 只显示真实能力。

### 4. CredentialImporter

每个导入适配器实现：

- `detect(source)`
- `preview(source)`
- `import(preview_id, target_profile, conflict_policy)`
- `resync(source_id)`
- `capabilities()`

预览保存在短期内存会话中，不能把秘密写入 SQLite、前端状态或日志。重新同步为用户主动触发的单向 `来源 → OMP` 操作，绝不修改来源。

## 能力探测

至少验证下列官方能力，但不要假设所有版本都存在：

- `omp --version`
- `omp --help`
- `omp config path`
- `omp config list --json`
- `omp models --json`
- `omp usage` 的 JSON/脱敏能力（先通过 `--help` 探测精确参数）
- `omp --profile <name>`
- `omp --cwd <dir>`
- `omp --resume <id或路径>`
- `omp --fork <session>`
- `omp --export <session>`
- `omp auth-broker ... --json`
- `omp auth-gateway check ... --json`
- `omp update`

缓存探测结果时同时保存 OMP 二进制路径、版本、mtime/hash 和探测时间。二进制变化后使缓存失效。每个功能由 capability flag 控制，不把版本号判断散落在组件中。

## 路径与 Profile 绑定规则

实现一个外置、可迁移的项目绑定系统：

1. 项目使用规范化绝对路径标识，同时保存用户输入的展示路径。
2. 处理 Windows 盘符和大小写、UNC、空格、中文、符号链接、尾部分隔符以及不存在路径。
3. Git 仓库尽量使用 shared/common Git directory 加仓库内相对子路径生成稳定身份，使 worktree 能共享绑定。
4. 支持路径前缀规则；最长前缀优先，子目录覆盖父目录。
5. 绑定保存在应用数据目录，不写入项目仓库。
6. 每个绑定可以保存：Profile、常用/高级模型角色、允许模型、禁用提供商、账号策略、默认终端方式。
7. 默认账号策略为 OMP 自动选择。固定 Profile 是稳定功能；固定具体凭证仅在 capability `can_pin` 为真时开放。

启动设置优先级从高到低：

1. 本次启动弹窗显式覆盖。
2. 恢复会话原模型、思考等级和 credential pin。
3. 项目路径绑定。
4. Profile 默认配置。
5. OMP 全局默认值。

在 UI 和领域对象中保留每个值的 `source`，例如 `launch_override`、`session`、`project`、`profile`、`global`。

## LaunchPlan：先预览，再执行

所有启动必须先生成不可变、可验证、可脱敏展示的 `LaunchPlan`。它至少包含：

```text
target_id
omp_executable
cwd
profile
action: new | resume | fork | export
session_ref?
model_roles
thinking_level?
credential_policy
terminal_mode: embedded | external
args[]
env_allowlist
temporary_config?
display_preview_redacted
warnings[]
```

执行前后再次校验：

- 可执行文件仍是探测过的 OMP。
- `cwd` 是已授权项目路径。
- Profile 和 session_ref 属于当前 target。
- 模型使用精确 `provider/modelId`。
- 参数数组中没有秘密。
- 临时配置位于应用私有临时目录、权限受限且不含凭证。

通过系统进程 API直接传 `executable + args[]`，禁止使用用户可控的 `sh -c`、`cmd /c`、PowerShell 拼接字符串。安装器是单独的高风险流程，也必须使用固定官方来源、明确预览和用户确认。

## 页面与交互

### 概览

- OMP 路径、版本、能力和更新状态。
- Profile、凭证健康、最近项目/会话、运行中终端。
- 快速选择项目、新建、继续和重新检测。

### 项目

- 添加文件夹；从已有会话 `cwd` 自动发现候选项目。
- 项目卡片显示 Profile、默认模型、会话数、最近使用和健康摘要。
- 项目详情可编辑路径绑定与默认值。
- 点击项目后进入该项目的全部会话列表，不自动恢复最新会话。

### 会话

- 字段：标题、首条消息摘要、创建/修改时间、状态、模型、提供商、账号掩码、消息数和大小。
- 搜索标题、首条消息；可选全文本地索引。支持按状态、日期、模型和账号筛选。
- 只读预览、收藏、标签、显示别名、恢复、分叉、HTML 导出、打开文件位置、移入回收站。
- 收藏、标签和别名只写管理器 SQLite，不改 OMP JSONL。
- 截断/损坏 JSONL 显示部分可读，不影响其他会话。

### 启动弹窗

- 显示项目路径、Profile、新建/恢复/分叉、模型角色、思考等级、账号策略、终端方式。
- 恢复时同时显示“原设置”和“本次设置”。
- 每项显示来源；临时修改不默认保存到项目。
- 提供脱敏命令预览和警告。
- 允许“启动并保存为项目默认值”，但要明确列出将永久修改的字段。

### 账号与凭证

- 按 Profile 和提供商分组。
- 记录类别：OAuth、登录型 API Key、环境变量、`models.yml`、Auth Broker、导入来源。
- 显示掩码身份、组织、类型、来源、有效期、最后检查、健康、禁用/退避和用量摘要（若可得）。
- 状态：未知、可用、即将过期、过期、禁用、退避、失败、来源不可用。
- 根据能力显示登录/添加、编辑元数据、刷新、禁用/启用、注销/删除和测试。
- 登录必须承载 OMP 官方流程。完整密钥默认永不显示。

### 凭证测试

- 默认使用格式、到期、刷新、usage 或 Auth Gateway 非严格检查，避免真实模型费用。
- 严格检查若会调用模型，按钮和确认框都写明“可能消耗额度”。
- 支持取消、超时、有限并发和提供商级退避。
- 只保存状态、错误分类和时间，不保存响应正文。

### 导入与同步

第一批适配器：

1. OMP 原生 Profile/本地存储迁移。
2. OMP Auth Broker 支持的 CLIProxyAPI 风格 JSON 文件或目录。
3. 在格式可安全识别时支持 Codex、Claude、Gemini CLI 本地认证/配置。
4. 通用 JSON、YAML、`.env`、单文件、目录和手动 API Key。

任何“一键导入”都先显示预览：来源、提供商、掩码身份、类型、有效期、目标 Profile 和冲突。策略为跳过、替换、保留两份；默认按提供商 + 稳定身份指纹跳过重复。格式不确定时 fail closed。

### 模型

- 从 `omp models --json` 获取列表，选择器始终为 `provider/modelId`。
- 显示上下文窗口、最大输出、推理/输入能力、费用和认证可用性（若 OMP 提供）。
- 默认角色：`default`、`smol`、`slow`、`plan`。
- 高级设置根据配置架构/能力列出全部角色，例如 `vision`、`designer`、`commit`、`tiny`、`task`、`advisor`；不要把示例永久硬编码为完整集合。
- 支持 Profile 默认和项目覆盖，显示配置层级。
- 自定义提供商用表单 + `models.yml` 预览；保存前验证、备份、原子写入。

### 终端

- 内嵌终端使用真实 PTY 与 xterm.js，支持多标签、resize、Ctrl+C、复制粘贴、颜色、退出码、正常/强制终止。
- Windows 使用 ConPTY；Linux 使用本机 PTY。
- 外部终端优先 Windows Terminal，回退到 PowerShell/命令提示符；Linux 使用系统默认终端并检测常见终端。
- 外部终端缺失时允许切换内嵌终端。
- 关闭仍在运行的内嵌终端先确认并优雅终止。

### 设置、诊断和回收站

- 设置：语言、主题、OMP 路径、默认终端、日志级别、隐私、全文索引开关。
- 诊断：OMP 版本/能力、Agent 目录、配置解析、路径权限、PTY、外部终端、会话扫描、凭证检查。
- 诊断导出默认不含会话正文和环境变量；导出前进行第二次秘密扫描。
- 会话删除时连同对应附件目录一起原子移入应用回收站；可恢复。清空回收站显示数量和大小并确认。

## 数据存储

使用 SQLite migrations。至少建立：

- `execution_targets`
- `omp_installations`
- `projects`
- `project_bindings`
- `project_role_defaults`
- `session_index`
- `session_annotations`
- `credential_aliases`
- `import_sources`
- `import_records`
- `trash_items`
- `app_settings`

强制规则：

- 所有关联数据带 `target_id`。
- 数据库绝不出现 API Key、Access Token、Refresh Token、Cookie 或完整授权头。
- 只缓存 opaque credential reference、掩码身份、别名、状态和时间。
- 迁移前备份；迁移失败回滚并保留旧文件。
- 会话全文索引默认本地且可关闭/清除。关闭时不保留正文。

## 配置写入

- 先读取 OMP 配置架构和有效层级。
- 基础表单和高级 YAML 共用同一验证层。
- 写入同目录临时文件，刷新后原子 rename；写入前创建时间戳备份。
- 尽可能保留 YAML 注释与键顺序。
- 数组是替换而非追加时在 UI 差异预览中明确说明。
- 凭证不写项目配置；使用 OMP 原生认证、Broker、环境引用或不受版本控制的安全覆盖。
- 本次启动的临时覆盖放应用私有目录，通过 OMP `--config` 传入，退出后清理；不得包含秘密。

## 安装与升级

检测顺序：用户指定路径 → `PATH` → 平台常见安装位置。使用 `omp --version` 验证，不因文件名相同就信任。

一键安装/升级必须：

1. 使用 OMP 官方来源和当时官方推荐命令。
2. 先显示 URL、命令、目标和安全说明，获得明确确认。
3. 不把任何项目路径或凭证插入安装 shell 命令。
4. 优先把固定官方脚本下载到权限受限临时文件、验证下载成功后由明确的解释器执行；若选择官方管道命令，必须隔离为固定模板且无用户插值。
5. 捕获并脱敏日志，允许取消；完成后重新探测。
6. 升级失败时保持现有 OMP 可运行，不删除未知文件。
7. 应用不捆绑固定 OMP 版本，维护已验证能力矩阵。

## 安全硬要求

这些要求不可用“后续优化”代替：

1. Tauri capability 最小化，禁止 WebView 任意 shell、任意文件和任意 URL 权限。
2. 所有 IPC 输入在 Rust 侧重新验证；TypeScript 类型不是安全边界。
3. 允许目录基于已授权项目、OMP Agent 目录、明确选择的导入/导出路径；处理 `..`、符号链接逃逸和 TOCTOU。
4. 进程统一使用参数数组。用包含空格、中文、`&`、引号、分号、换行和 `$()` 的路径做注入测试。
5. 前端、SQLite、URL、日志、错误、通知、剪贴板、遥测和崩溃报告中不出现秘密。
6. 实现集中式脱敏器，覆盖 Bearer、常见 Key、Cookie、URL 查询参数、JSON/YAML 敏感字段和 OMP 配置字段。
7. 原始凭证只在 Rust 内存中停留最短时间；能力允许时使用 zeroize。不要在 Redux/Zustand/localStorage 持有。
8. 默认无遥测、无公网监听。OAuth 回调/Broker 仅绑定回环地址并校验 state/bearer。
9. 外部导入只读，限制文件大小、数量、递归、符号链接和解析深度；不执行脚本、模板或 hook。
10. 删除、覆盖、严格测试和网络安装器都要显示精确目标并确认。
11. 会话正文不进入诊断包；用户明确选择时也要警告和脱敏。
12. 不默认请求管理员/root 权限；需要时交给操作系统针对单一步骤授权。

创建 `docs/threat-model.md`，至少分析：恶意项目路径、恶意会话内容导致 XSS、日志泄密、导入源投毒、配置竞态、临时文件窃取、Broker Token 泄露和依赖供应链。

## 错误与降级体验

每个页面都要能处理：加载、空状态、部分成功、取消、超时、权限拒绝、版本不兼容和可重试错误。

特别要求：

- OMP 缺失：显示安装/选路径/重新检测，不展示假清单。
- JSON 能力缺失：明确进入受限模式；只在解析安全且有测试时使用文本回退。
- 会话损坏：部分预览、只读、建议备份。
- 账号被限流：显示退避截止时间，停止该提供商批量检查。
- 导入源消失：保留历史，不删除目标。
- `can_pin = false`：禁用固定具体凭证，仍允许 Profile 固定和自动选择。
- PTY 失败：保留脱敏错误并提供外部终端回退。
- 更新失败：保留旧 OMP 并重新探测。

## 测试要求

### Rust 单元测试

- Windows/Linux 路径规范化、UNC、大小写、符号链接。
- Git worktree/common-dir 身份与最长前缀匹配。
- LaunchPlan 合并优先级与来源标记。
- 参数数组构建与命令注入阻断。
- JSONL 正常、未知记录、截断、损坏、运行中追加。
- OMP JSON 多版本 fixture 解析和 capability 映射。
- 配置验证、备份、原子写入与回滚。
- 脱敏器的正向、负向和嵌套数据测试。
- 导入检测、去重、冲突和 fail-closed。
- 回收站移动、恢复和冲突。

### TypeScript 测试

- 配置来源展示和启动弹窗状态。
- 项目 → 全部会话 → 恢复/覆盖流程。
- 凭证 capability 控制和严格测试确认。
- 导入预览与冲突选择。
- 错误、空状态、键盘和焦点行为。
- i18n key 完整性，组件中无关键硬编码字符串。

### 集成测试

- 使用临时 Agent 目录和 stub `omp` 可执行文件，覆盖各命令、退出码、超时、无效 JSON 和 stderr。
- 使用合成凭证与会话 fixture，绝不读取测试机器真实 `~/.omp`。
- PTY 启动、输入、resize、Ctrl+C、退出码和终止。
- SQLite 迁移、崩溃中断、重启恢复。
- Tauri IPC 对未授权路径和命令的拒绝。

### 端到端场景

1. OMP 缺失 → 用户确认安装 → 重新检测。
2. 添加两个项目 → 绑定不同 Profile → 分别新建会话。
3. 点击项目 → 列出全部历史会话 → 选择一条 → 查看原设置 → 覆盖模型 → 内嵌终端恢复。
4. 同一流程改用外部终端。
5. 导入预览 → 冲突跳过 → 同步 → 安全检查 → 禁用/恢复。
6. 会话移入回收站 → 恢复。
7. 老版本 OMP → 部分能力禁用且解释清楚。

测试路径必须包含：空格、中文、emoji、`&`、单/双引号、分号、换行或平台允许的其他危险字符。使用假 Key 验证任何构建产物、日志和诊断包都不包含该字符串。

## 性能基线

- 先显示缓存框架，再后台探测；不要让冷启动被所有 OMP 子进程串行阻塞。
- 1,000 个会话时列表快速可交互；会话扫描并发有界，解析在后台完成。
- 全文索引增量更新、可暂停、可关闭和可清除。
- UI 主线程不读大文件、不运行子进程。
- 批量凭证检查默认总并发不超过 3，同一提供商不超过 1，并尊重退避。

## 里程碑实施顺序

### M0：事实验证与骨架

交付：

- Tauri/React/Rust 可运行骨架和最小权限配置。
- `ExecutionTarget`、`OmpAdapter`、`CredentialBackend`、`CredentialImporter` 接口。
- OMP 能力探测 CLI 与脱敏 fixture。
- `docs/architecture.md`、`docs/threat-model.md`、`docs/omp-compatibility.md`。
- Windows/Linux PTY spike。
- 明确本地凭证 CRUD 与 credential pin 的安全实现结论。

M0 验收后再继续，不要隐藏未解决的凭证接口问题。

### M1：纵向可运行版本

交付完整闭环：

`检测 OMP → 添加项目 → 绑定 Profile → 列出会话 → 选择新建/恢复 → 选择模型 → 预览 LaunchPlan → 内嵌 PTY 启动`

同时交付 SQLite migration、错误模型、脱敏日志和自动化测试。

### M2：第一版功能完成

- 外部终端、分叉、导出、回收站。
- 凭证总览、登录/管理、安全/严格测试。
- 外部导入、预览、冲突、重新同步。
- 模型角色基础/高级设置和自定义提供商。
- 安装、升级、诊断导出、中文 UI、主题。

### M3：发布质量

- Windows x64 安装包。
- Linux x64 AppImage 与至少一种发行版包。
- CI 中的 lint、typecheck、unit、integration、build。
- 依赖审计、许可证清单、隐私说明、数据清除说明。
- 为签名、自动更新、ARM64 和英文完整翻译保留清晰任务；不要假装未配置的签名已经完成。

## Definition of Done

一个功能只有同时满足以下条件才算完成：

- 连接真实领域服务，不是 UI 假数据。
- 有加载、空、成功、取消、错误和能力缺失状态。
- 有对应测试，且测试不读取真实用户数据。
- 日志和错误已脱敏。
- 权限范围已审查。
- 中英文 i18n key 已加入。
- 文档说明数据位置、恢复方式和已知限制。
- Windows 与 Linux 的差异被抽象或明确测试。

第一版整体完成时，必须做到：

1. 从干净 clone 按 README 能启动开发环境、运行测试并构建安装包。
2. 所有 lint、format、typecheck、单元和集成测试通过。
3. 核心流程没有 TODO、空按钮、静态假清单或吞掉错误的 catch。
4. 需求文档中的 AC-01 至 AC-08 有自动化测试或可复现的人工验收记录。
5. 给出已验证 OMP 版本、能力差异和明确的降级清单。
6. 用合成秘密执行扫描，确认源码、构建产物、SQLite、日志和诊断包无泄露。
7. 不直接写 `agent.db`，不改写 OMP 会话 JSONL，不从前端执行任意 shell。

## 最终交付清单

- 可运行源代码与锁文件。
- Windows/Linux 开发与打包说明。
- 数据库 migrations。
- 合成测试 fixture 与完整测试。
- `README.md`。
- `docs/architecture.md`。
- `docs/threat-model.md`。
- `docs/omp-compatibility.md`。
- `docs/development.md`。
- 用户数据位置、备份、卸载和回收站说明。
- 当前限制与下一步 WSL/SSH 执行目标设计说明。

开始时先输出一份简洁的仓库检查结果和 M0 实施计划，然后立即落地 M0。不要重复询问上面已经确定的产品偏好。
